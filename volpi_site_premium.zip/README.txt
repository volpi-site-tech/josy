VOLPI - Static site (for Netlify)
---------------------------------
Deploy: upload the contents of this folder to Netlify (drag & drop) or to a Git repository connected to Netlify.
Features:
- Palette in olive, nude, beige, cream, white, gold.
- Logo (SVG), hero image and profile image included.
- Catalog with client-side editor (localStorage). Add / edit / export JSON.
- Contact links (WhatsApp, Instagram, Email).
Notes:
- To add initial property images, use the "Novo imóvel" button and upload files.
- For production, replace client-side storage with a real backend / CMS.
Contact: volpinegociosimobiliarios@gmail.com
