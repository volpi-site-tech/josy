
// Simple client-side catalog editor using localStorage
const LS_KEY = "volpi_listings_v1";
let listings = JSON.parse(localStorage.getItem(LS_KEY) || "[]");

function saveListings(){ localStorage.setItem(LS_KEY, JSON.stringify(listings)); renderListings(); }

function renderListings(){
  const container = document.getElementById("listings");
  container.innerHTML = "";
  if(listings.length===0){
    container.innerHTML = '<p class="muted">Nenhum imóvel cadastrado. Clique em "Novo imóvel" para adicionar.</p>';
    return;
  }
  listings.forEach((it, idx)=>{
    const card = document.createElement("article");
    card.className = "card";
    const thumb = it.media && it.media[0] ? `<img src="${it.media[0]}" alt="${it.name}">` : '';
    card.innerHTML = `
      ${thumb}
      <h3>${it.name || "Sem nome"}</h3>
      <div class="features">${(it.features||[]).slice(0,5).join(" · ")}</div>
      <div class="price">${it.price ? "R$ " + Number(it.price).toLocaleString('pt-BR') : "Valor sob consulta"}</div>
      <p class="muted">${(it.description||"").slice(0,140)}${(it.description||"").length>140?"…":""}</p>
      <div style="display:flex;gap:8px;margin-top:10px">
        <button data-edit="${idx}" class="btn">Editar</button>
        <button data-view="${idx}" class="btn outline">Ver</button>
        <button data-delete="${idx}" class="btn">Excluir</button>
      </div>
    `;
    container.appendChild(card);
  });
}

// Modal and form logic
const modal = document.getElementById("editorModal");
const form = document.getElementById("listingForm");
const newBtn = document.getElementById("newListingBtn");
const cancelBtn = document.getElementById("cancelBtn");
const editorTitle = document.getElementById("editorTitle");
let editingIndex = null;

newBtn.addEventListener("click", ()=>{
  editingIndex = null;
  editorTitle.textContent = "Novo imóvel";
  form.reset();
  showModal();
});

cancelBtn.addEventListener("click", hideModal);

form.addEventListener("submit", async (e)=>{
  e.preventDefault();
  const fd = new FormData(form);
  const name = fd.get("name");
  const description = fd.get("description");
  const features = fd.get("features") ? fd.get("features").split(",").map(s=>s.trim()).filter(Boolean) : [];
  const price = fd.get("price");
  const files = fd.getAll("media");
  let media = [];
  // convert files to base64 for local preview/storage
  for(const f of files){
    if(typeof f === "string") continue;
    if(!f || f.size===0) continue;
    media.push(await toBase64(f));
  }
  const obj = {name, description, features, price, media};
  if(editingIndex===null){
    listings.unshift(obj);
  } else {
    listings[editingIndex] = obj;
  }
  saveListings();
  hideModal();
});

function toBase64(file){ return new Promise((res,rej)=>{
  const reader = new FileReader();
  reader.onload = ()=>res(reader.result);
  reader.onerror = ()=>rej("erro");
  reader.readAsDataURL(file);
});}

function showModal(){ modal.classList.remove("hidden"); modal.setAttribute("aria-hidden","false"); }
function hideModal(){ modal.classList.add("hidden"); modal.setAttribute("aria-hidden","true"); }

document.getElementById("listings").addEventListener("click",(e)=>{
  const edit = e.target.dataset.edit;
  const view = e.target.dataset.view;
  const del = e.target.dataset.delete;
  if(edit!==undefined){
    editingIndex = Number(edit);
    const it = listings[editingIndex];
    editorTitle.textContent = "Editar imóvel";
    form.name.value = it.name || "";
    form.description.value = it.description || "";
    form.features.value = (it.features||[]).join(", ");
    form.price.value = it.price || "";
    showModal();
  } else if(view!==undefined){
    const it = listings[Number(view)];
    viewListing(it);
  } else if(del!==undefined){
    if(confirm("Excluir este imóvel?")){ listings.splice(Number(del),1); saveListings(); }
  }
});

function viewListing(it){
  const win = window.open("", "_blank");
  const html = `
  <html><head><meta charset="utf-8"><title>${it.name}</title><style>body{font-family:Arial;padding:20px;color:#222} img{max-width:100%;height:auto;border-radius:8px}</style></head>
  <body><h1>${it.name}</h1><p><strong>Valor:</strong> ${it.price? "R$ "+Number(it.price).toLocaleString('pt-BR') : "Sob consulta"}</p>
  <p><strong>Características:</strong> ${(it.features||[]).join(", ")}</p>
  <p>${it.description||""}</p>
  ${(it.media||[]).map(src=> `<img src="${src}">`).join("")}
  </body></html>`;
  win.document.write(html);
}

// export
document.getElementById("exportBtn").addEventListener("click", ()=>{
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(listings, null, 2));
  const a = document.createElement("a");
  a.href = dataStr; a.download = "catalogo_volpi.json"; a.click();
});

// initial render
renderListings();
